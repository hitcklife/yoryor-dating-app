import { config } from "@gluestack-ui/config";
import { createConfig } from "@gluestack-ui/themed";

export const gluestackConfig = createConfig({aliases: undefined, tokens: undefined, config });
